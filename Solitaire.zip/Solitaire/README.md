# Outline

## Define data structures
- card
- deck
- types

## Create utility functions

## DOM Visualization

## User interaction

## Game rules
