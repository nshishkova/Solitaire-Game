import { Card, Deck, faces, suits } from './cards.js';

export function createMainDeck() {
    const deck = new Deck();

    for (let suit of Object.values(suits)) {
        for (let face of Object.values(faces)) {
            deck.cards.push(new Card(suit, face));
        }
    }

    return deck;
}

/**
 * 
 * @param {Deck} deck 
 */
export function shuffleDeck(deck) {
    const stock = [];

    while (deck.size > 0) {
        const card = deck.cards.splice(Math.random() * deck.size | 0, 1)[0];
        stock.push(card);
    }

    deck.cards.push(...stock);
}

/**
 * 
 * @param {Deck} deck 
 * @returns {[Deck[], GameState]}
 */
export function dealDeck(deck) {
    const index = [
        new Deck(), // stock
        new Deck(), // waste
        new Deck(), // foundation Clubs
        new Deck(), // foundation Diamonds
        new Deck(), // foundation Hearts
        new Deck(), // foundation Spades
        new Deck(), // pile 1
        new Deck(), // pile 2
        new Deck(), // pile 3
        new Deck(), // pile 4
        new Deck(), // pile 5
        new Deck(), // pile 6
        new Deck(), // pile 7
    ];

    /** @type {GameState} */
    const state = {
        stock: index[0],
        waste: index[1],
        foundations: /** @type {GameState['foundations']} */ ({
            [suits.Clubs]: index[2],
            [suits.Diamonds]: index[3],
            [suits.Hearts]: index[4],
            [suits.Spades]: index[5],
        }),
        piles: [
            index[6],
            index[7],
            index[8],
            index[9],
            index[10],
            index[11],
            index[12],
        ]
    };

    for (let i = 0; i < 7; i++) {
        const pile = state.piles[i];

        for (let j = 0; j <= i; j++) {
            pile.cards.push(deck.cards.pop());
        }

        pile.top.faceUp = true;
    }

    state.stock.cards.push(...deck.cards);

    return [ index, state ];
}

/**
 * @typedef {Object} GameState
 * @property {Deck} stock
 * @property {Deck} waste
 * @property {Record<import('./cards.js').CardSuit, Deck>} foundations
 * @property {[Deck, Deck, Deck, Deck, Deck, Deck, Deck]} piles
 */

