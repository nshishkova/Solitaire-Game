/** @type {Record<string, CardSuit>} */
export const suits = {
    Clubs: 'clubs',
    Diamonds: 'diamonds',
    Hearts: 'hearts',
    Spades: 'spades'
};

/**
 * @typedef {number} CardFace
 */

export const faces = {
    Ace: 1,
    Two: 2,
    Three: 3,
    Four: 4,
    Five: 5,
    Six: 6,
    Seven: 7,
    Eigth: 8,
    Nine: 9,
    Ten: 10,
    Jack: 11,
    Queen: 12,
    King: 13,
};

/**
 * @typedef {'clubs'|'diamonds'|'hearts'|'spades'} CardSuit
 */

export const colors = {
    clubs: 'black',
    diamonds: 'red',
    hearts: 'red',
    spades: 'black',
};

export class Card {
    /** @type {CardSuit} */
    suit = null;
    /** @type {CardFace} */
    face = null;
    /** @type {boolean} */
    faceUp = false;


    /**
     * 
     * @param {Card['suit']} suit 
     * @param {Card['face']} face 
     * @param {boolean?} faceUp 
     */
    constructor(suit, face, faceUp = false) {
        this.suit = suit;
        this.face = face;
        this.faceUp = faceUp;

    }
}

// const card = new Card(suits.Clubs, faces.King, true);
// console.log(card)

export class Deck {
    /** @type {Card[]} */
    cards = [];

    // they are hoisted - it doesn't matter if the topIndex() is below or above the top()
    get size() {
        return this.cards.length;
    }

    get topIndex() {
        return this.size - 1; // the index of the last card on the top of the deck
    }

    get top() {
        return this.cards[this.topIndex]; // the last card on the top of the deck
    } // if the deck is empty it will return undefined

    /**
     * 
     * @param {Deck['cards']?} cards 
     */
    constructor(cards = []) {
        this.cards = cards;
    }

    flip() { // it always work on the card on the top
        this.top.faceUp = true;
    }

    /**
     * 
     * @param {number} index 
     */
    take(index) { //the index of the card that we want
        return this.cards.splice(index, this.size - index); //slice n number of cards and it returns them
    }

    /**
     * 
     * @param {Card[]} cards 
     */
    place(cards) {
        this.cards.push(...cards); //we will get all cards and we will push them to the collection
    }
}