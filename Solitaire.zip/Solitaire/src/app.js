import { createDeckElement } from './dom.js';
import { createMainDeck, dealDeck, shuffleDeck } from './utils.js';

const zones = {
    stock: document.getElementById('stock'),
    foundations: document.getElementById('foundation'),
    piles: document.getElementById('pile'),
};

start();

function start() {
  const mainDeck = createMainDeck();

  for (let n = 0; n < 6; n++){ 
      shuffleDeck(mainDeck);
  }

  const [deckIndex, state] = dealDeck(mainDeck);

  stateToBoard(state);

}

/**
 * 
 * @param {import('./utils.js').GameState} state 
 */
function stateToBoard(state) {
    zones.stock.replaceChildren(
        createDeckElement(state.stock),
        createDeckElement(state.waste),
    );
    zones.foundations.replaceChildren(...Object.values(state.foundations).map(createDeckElement));
    zones.piles.replaceChildren(...state.piles.map(createDeckElement));
}

