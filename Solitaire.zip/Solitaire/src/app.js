import { Card, faces, suits } from './cards.js';
import { createCardElement } from './dom.js';

const card = new Card(suits.Hearts, faces.Five, true);

const element = createCardElement(card, true);
console.log(element);

document.getElementById('stock').appendChild(element);


