//import { Card } from './cards.js';

import { colors } from './cards.js';

const suits = {
    clubs: '&clubs;',
    diamonds: '&diams;',
    hearts: '&hearts;',
    spades: '&spades;'
};

const faces = {
    1: 'A',
    2: '2',
    3: '3',
    4: '4',
    5: '5',
    6: '6',
    7: '7',
    8: '8',
    9: '9',
    10: '10',
    11: 'J',
    12: 'Q',
    13: 'K',
};

/**
 * 
 * @param {import('./cards.js').Card} card 
 * @param {boolean} isTop 
 */
export function createCardElement(card, isTop) {
    const element = document.createElement('div');
    element.classList.add('card');
    element.classList.add('top');

    if (card.faceUp) {
        element.innerHTML = `${suits[card.suit]}${faces[card.face]}`;
        element.classList.add(colors[card.suit]);
    }

    return element;
}
